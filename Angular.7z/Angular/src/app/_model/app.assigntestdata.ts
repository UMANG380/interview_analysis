export class AssignTestData{
    userId:number;
    testId:number;
}