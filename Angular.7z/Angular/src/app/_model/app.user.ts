import { Test } from "./app.test";

export class User{
    userId:any;
    userName:string;
    userPassword:string;
    isAdmin:boolean;
    isDeleted:boolean;
}