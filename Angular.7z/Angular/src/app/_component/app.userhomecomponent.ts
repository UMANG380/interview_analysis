import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';

export interface IImage {
    url: string | null;
    href?: string;
    clickAction?: Function;
    caption?: string;
    title?: string;
    backgroundSize?: string;
    backgroundPosition?: string;
    backgroundRepeat?: string;
  }

@Component({
    selector: 'user',
    templateUrl: '../_html/app.user.html'
})

export class UserHomeComponent implements OnInit {

    imageUrls: (string | IImage)[] = [
        { url: 'https://cdn.ila-france.com/wp-content/uploads/2017/01/french-test-1750x660-1.jpg' },
        { url: 'https://www.chronicle.com/blogs/linguafranca/files/2018/11/job-interview.jpg' },
        { url: 'https://d1whtlypfis84e.cloudfront.net/guides/wp-content/uploads/2018/09/26173831/histogram2.png' },
        { url: 'https://www.totaljobs.com/insidejob/wp-content/uploads/2018/05/how-to-answer-competency-based-interview-questions.jpg' },
        
      ];
    
    constructor(private router:Router){}
    ngOnInit(){
        if(sessionStorage.getItem("role")!= "user"){
            this.router.navigate(['/error403'])
        }
    }
}