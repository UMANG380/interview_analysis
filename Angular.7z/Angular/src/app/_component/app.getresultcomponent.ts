import { Component, OnInit} from '@angular/core';
import { UserService } from '../_service/app.userservice';
import {saveAs} from 'file-saver';
import { Router } from '@angular/router';
export interface IImage {
  url: string | null;
  href?: string;
  clickAction?: Function;
  caption?: string;
  title?: string;
  backgroundSize?: string;
  backgroundPosition?: string;
  backgroundRepeat?: string;
}
@Component({
    selector: 'listuser',
    templateUrl: '../_html/app.getresult.html'
})

export class GetResultComponent implements OnInit{

    header:string;
    dataSource: Object;
    imageUrls: (string | IImage)[] = [
      { url: 'https://cdn.ila-france.com/wp-content/uploads/2017/01/french-test-1750x660-1.jpg' },
      { url: 'https://www.chronicle.com/blogs/linguafranca/files/2018/11/job-interview.jpg' },
      { url: 'https://d1whtlypfis84e.cloudfront.net/guides/wp-content/uploads/2018/09/26173831/histogram2.png' },
      { url: 'https://www.totaljobs.com/insidejob/wp-content/uploads/2018/05/how-to-answer-competency-based-interview-questions.jpg' },
      
    ];
    constructor(private service:UserService, private router:Router){
        
        console.log("In Constructor");
    }

    ngOnInit(){
        if(sessionStorage.getItem("role")!= "user"){
            this.router.navigate(['/error403'])
        }
        else{
            this.service.getResult().subscribe((data:string) =>this.header =data);
            this.dataSource = {
                chart: {
                  caption: "Marks Analysis",
                  subCaption: "",
                  xAxisName: "Candidate Name",
                  yAxisName: "Marks",
                  numberSuffix: "",
                  theme: "fusion"
                },
                // Chart Data
                data: [
                  
                  {
                    label: "Uttkarsh",
                    value: "80"
                  },
                  {
                    label: "Tushar",
                    value: "90"
                  },
                  {
                      label: "Divya",
                      value: "80"
                   },
                  {
                    label: "Avantika",
                    value: "95"
                  },
                 
                ]
              };
        }
    }
    resultPdf(){
       
    }

}